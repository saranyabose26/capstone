module.exports = {
  secretKey: "admin_server_key",
};
