module.exports = {
  PASSWORD: "db_password",
  DBNAME: "db_name",
};
