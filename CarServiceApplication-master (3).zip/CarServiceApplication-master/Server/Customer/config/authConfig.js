module.exports = {
  secretKey: "customer_server_key",
};
