import React from "react";

function Cust_Contact() {
  return (
    <div>
      <h1>COntact US</h1>
      <h1>COntact US</h1>
      <h1>COntact US</h1>
    </div>
  );
}

export default Cust_Contact;
